/* SPDX-License-Identifier: GPL-2.0-only */

#ifndef _ASM_VERMAGIC_H
#define _ASM_VERMAGIC_H


#ifdef CONFIG_VIVO_MODULE_VERMAGIC
#define MODULE_ARCH_VERMAGIC	"vivo aarch64"
#else
#define MODULE_ARCH_VERMAGIC	"aarch64"
#endif

#endif 
